<?php
include_once('include/config.php');
 if (isset($_POST['submit'])) { 
$registerd_date=$_POST['date'];
$password=$_POST['password'];
$username=$_POST['username'];
$usertype=$_POST['usertype'];
$name=$_POST['name'];
if($usertype="checker")
{
	$uservalue=3;
}
else
{	
$uservalue=3;
}

$query=mysqli_query($con,"insert into user(usertype,name,username,password,uservalue,registerd_date) 
values('$usertype','$name','$username','$password','$uservalue','$registerd_date')");
////$query="insert into student(first_name,last_name,gender,email,institute,qrcode) 
//values('$firstname','$lastname','$gender','$email','$institute','$firstname)";
//echo $query;
if($query)
{
	echo "<script>alert('Successfully Added your Data . ');</script>";
	
	//  echo $query;     	//header('location:dashboard.php');
	//header('location:registration.php');
}
else{
		echo "<script>alert('Error Your Data');</script>";
        //	header('location:dashboard.php');

}

 }
?>