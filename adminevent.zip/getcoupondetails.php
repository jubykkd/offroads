<?php
include_once('include/config.php');
$id = $_POST['couponnumber']; // Retrieve id data sent via AJAX
$query = mysqli_query($con, "SELECT * FROM coupon WHERE coupon_number='".$id."'"); // Show student data with the id
$row = mysqli_num_rows($query); // Calculate how much data from the $query execution results
if($row > 0){ // If the data is more than 0
  $data = mysqli_fetch_array($query); // take the student's data
  
  // BUat sebuah array
  $callback = array(
    'status' => 'success', // Set array status with success
    'disamount' => $data['amount'],
	    'discounttype' => $data['discounttype'],
    'limitofcoupon' => $data['limitofcoupon'],

	// Set array name with the contents of the name field in the student table
      );
}else{
  $callback = array('status' => 'failed'); // set the status array with failed
  
}

echo json_encode($callback); // converting varibel $callback to JSON
?>