<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
 
require 'vendor/autoload.php';
$mail = new PHPMailer(true);


include "qrlib.php";
include_once('include/config.php');
        $matrixPointSize = min(max((int)$_POST['size'], 1), 10);
 if (isset($_POST['submit'])) { 
 
    $firstname=$_POST['firstname'];
	$lastname=$_POST['lastname'];
	$institute=$_POST['institute'];
	$gender=$_POST['gender'];
	$mobile=$_POST['mobile'];
	$email=$_POST['email'];
	$registerd_date=date("Y/m/d");
	$prefix='OFR';
	$verified="Email Send";
	$checkedin="Registerd";
	$couponamount=$_POST['couponamount'];
	$coupondiscount=$_POST['coupondiscount'];
	$totalamount=$_POST['totalamount'];
	$couponnumber=$_POST['couponnumber'];
$student_id = $prefix . rand();
   $programlist=$_POST['programlist'];
	$path = 'qrcodeimages/'; 
$filename = $path.uniqid().".png"; 
$qrcode = $firstname . " " . $student_id;

// $ecc stores error correction capability('L') 
$ecc = 'L'; 
$pixel_Size = 10; 
$frame_Size = 10; 
QRcode::png($qrcode, $filename, $ecc, $pixel_Size, $frame_Size); 
//$path = $filename ;
    $path1="https://offroadsmbcet.in/adminevent/";
	$path=$path1.$filename;

// Displaying the stored QR code from directory 
echo "<center><img src='".$filename."'></center>"; 


	
	
	
	

$query=mysqli_query($con,"insert into student(first_name,last_name,gender,email,institute,qrcode,mobile,verified,checkedin,registerd_date,qrcodelocation) 
values('$firstname','$lastname','$gender','$email','$institute','$qrcode','$mobile','$verified','$checkedin','$registerd_date','$filename')");
if($query)
{
	  $student_id = $con->insert_id;
    foreach($programlist as $programid)
	{

	
$query1=mysqli_query($con,"insert into  studentrevenue(studentid,totalamount,discount_amount,coupon_number,registerddate,program)values('$student_id','$totalamount','$coupondiscount','$couponnumber','$registerd_date','$programid')");	
	//$query1="insert into  studentrevenue(studentid,totalamount,discount_amount,couponnumber,registerddate,program)values('$student_id','$totalamount','$coupondiscount','$couponnumber','$registerd_date','$programid')";
	//echo $query1;
	}
	

	 if($query1)
	{
	echo "<script>alert('Successfully Added your Data . ');</script>";
	 	header('location:eventregistration.php');

	
	}
	else
	{
				echo "<script>alert('Error Your Data');</script>";

	}
	//echo "<script>alert('Successfully Added your Data . ');</script>";
	
	 //  echo $query;     	//header('location:dashboard.php');
	//header('location:userlist.php');
}
else{
		echo "<script>alert('Error Your Data');</script>";
        //	header('location:dashboard.php');

}

 try {
	 
    $mail->SMTPDebug = 2;                                       
    $mail->isSMTP();                                            
    $mail->Host       = "smtp.gmail.com";                    
    $mail->SMTPAuth   = true;                             
    $mail->Username   = "abhichandranonline@gmail.com";                 
    $mail->Password   = "krjl uucf nkhf llur";                        
    $mail->SMTPSecure = "tls";                              
    $mail->Port       =587;  
	    $mail->From = 'offroad2024tvm@gmail.com';
    //$mail->FromName = 'offroad';

  //  $mail->AddAddress($email, 'Information'); 
    //$mail->AddReplyTo($email, 'Wale');

    $mail->IsHTML(true);

    $mail->Subject = 'offroad event';
	
    $mail->setFrom('offroad2024tvm@gmail.com', 'Name');           
    $mail->addAddress($email);
    $mail->addAddress($email, 'Name');

      //$path2=$PNG_WEB_DIR.basename($filename);
      //$path = $path1 . $path2;

      
$myemail="offroad2024tvm@gmail.com";

   // $mail->Body    = "message send sucessfully <b> $firstname <img src="'.$PNG_WEB_DIR.basename($filename).'" />< /b> ";
    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
//$mail->Body="i get mail from $firstname";
 
 $message="
 				 <html>
				 <head>
				 <body >
				 <table style='width:500px;background-color: #AF70AB;border: 5px solid #ccc'>
				 <tr style=' border-bottom: p2x solid #ccc;border-bottom-style: dotted;
'>
				 
				 <td style=' border-bottom: 1px solid #ccc;border-bottom-style: dotted;
'>Qrcode
				 						 <img src=".$path.">

						 </td>
</tr>
                         <td  style='color:#fff;  font-size: 14px;
 ; font-family: 'Times New Roman', Times, serif;
'>FirstName .$firstname.</td>
						 
						 </tr>
						 <tr>
                        <td style='color:#fff;  font-size: 14px;
;  font-family: 'Times New Roman', Times, serif;
'>LatName  .$lastname.</td>
						</tr>
						<tr>
                         <td style='color:#fff;   font-size: 14px;
; font-family: 'Times New Roman', Times, serif;
'>Phone  .$mobile.'</td>
						 </tr>
						 
				

				 
				 				</table>
				</head>
				 </body>
				 </html>
				";

          $mail->Body  = "You have received a new message. ".
        " Here are the details:\n Name: $message \n ".
        "Email: $email\n Message \n $address";
    $headers = "From: $myemail\n";
    $headers .= "Reply-To: $email";

    $mail->isHTML(true);                                  
    //$mail->Subject = 'Subject';
    //$mail->Body    = 'HTML message body in <b>;sdfk;sfk;sf;ks;fkkf;skf;s;</b> ';
    //$mail->AltBody = 'Body in plain text for non-HTML mail clients';
    $mail->send();
    echo "Mail has been sent successfully!";

} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}


 }
 

   ?>
   
   
   
   
