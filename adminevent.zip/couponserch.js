function search(){
  //$("#loading").show(); // Show  the loading
  $.ajax({
        type: "POST", // The method of sending data can be with GET or POST
        url: "getcoupondetails.php", // Fill in url / php file path to destination
        data: {couponnumber : $("#couponnumber").val()}, // data to be sent to the process file
        dataType: "json",
        beforeSend: function(e) {
            if(e && e.overrideMimeType) {
                e.overrideMimeType("application/json;charset=UTF-8");
            }
    },
    success: function(response){ // When the submission process is successful
          //  $("#loading").hide(); // Hide loading
            //alert(id);
            if(response.status == "success"){ // If the content of the status array is success
        $("#coupondiscount").val(response.disamount); // set textbox with id name
		      //$("#couponamount").val("100");
			   $("#discounttype").val(response.discounttype); // set textbox with id name
		        //$("#couponamount").val(response.amount); // set textbox with id name

        //alert("dsddssdsd");
		// set textbox with id address
      }else{ // If the contents of the status array are failed
        alert("undefined");
      }
    },
        error: function (xhr, ajaxOptions, thrownError) { // When there is an error
      alert(xhr.responseText);
        }
    });
}


