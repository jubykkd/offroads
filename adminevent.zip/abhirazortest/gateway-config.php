<?php
//set your razorpay account keyid and keysecret , 
//get from razorpay account in settings 
$keyId='rzp_live_pwGqIi1hWyw9Zk'; 
$keySecret='JjLjLMaipKdgA04StyK3IQ7V';
?>