<?php session_start();
define('DBNAME','u319423367_event');
define('DBUSER','u319423367_event');
define('DBPASS','Jubish123@');
define('DBHOST','127.0.0.1:3306');
try {
  $db = new PDO("mysql:host=".DBHOST.";dbname=".DBNAME, DBUSER, DBPASS);
  $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  //echo "Your page is connected with database successfully..";
} catch(PDOException $e) {
  echo "Issue -> Connection failed: " . $e->getMessage();
}
?>