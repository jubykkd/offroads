<?php
include_once('include/config.php');

$coupon_number=$_POST['coupon_number'];
$description=$_POST['description'];
$discounttype=$_POST['discounttype'];
$amount=$_POST['amount'];
$limitofcoupon=$_POST['limitofcoupon'];
$visible=$_POST['visible'];

$query=mysqli_query($con,"insert into coupon(coupon_number,description,discounttype,amount,limitofcoupon,visible) 
values('$coupon_number','$description','$discounttype','$amount','$limitofcoupon','$visible')");

//$query="insert into coupon(coupon_number,description,discounttype,amount,limitofcoupon,visible) 
//values('$coupon_number','$description','$discounttype','$amount','$limitofcoupon','$visible')";
//echo $query;
if($query)
{
	echo "<script>alert('Successfully Added your Data . ');</script>";
	header('location:index.php');
}
else
{
					echo "<script>alert('Error Your Data');</script>";

}
?>
